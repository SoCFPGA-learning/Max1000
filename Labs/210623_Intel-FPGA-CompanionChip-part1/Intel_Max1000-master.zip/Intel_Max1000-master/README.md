# Intel_Max1000
Intel Companion chip for STM32 using Max1000

This repo contains the sldies / instructions and source code to rebuild the Intel-FPGA companion chip project


   ![Logo](/Pictures/1.png)
