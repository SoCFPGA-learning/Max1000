

const uint8_t test = 0xa5;

void print( char* data);
